import React from 'react';
import MainEstadoCaso from "@/components/maestros/estado-caso-components/main-estado-caso";

const EstadoCasoIndex = () => {
    return (
        <>
            <MainEstadoCaso/>
        </>
    );
};

export default EstadoCasoIndex;
