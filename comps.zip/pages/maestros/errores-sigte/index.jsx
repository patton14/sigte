import React from 'react';
import MainErroresSigte from "@/components/maestros/errores-sigte-components/main-errores-sigte";

const ErroresSigteIndex = () => {
    return (
        <>
            <MainErroresSigte/>
        </>
    );
};

export default ErroresSigteIndex;
