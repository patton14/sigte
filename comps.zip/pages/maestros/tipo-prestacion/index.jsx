import MainTipoPrestacion from '@/components/maestros/tipo-prestacion/main-tipo-prestacion'
import React from 'react'

function TipoPrestacionesIndex() {
    return (
        <>
            <MainTipoPrestacion/>
        </>
    )
}

export default TipoPrestacionesIndex
