import React from 'react';
import MainConfNotificacion from "@/components/maestros/conf-notificacion-components/main-conf-notificacion";

const ConfNotificacionIndex = () => {
    return (
        <>
            <MainConfNotificacion/>
        </>
    );
};

export default ConfNotificacionIndex;
