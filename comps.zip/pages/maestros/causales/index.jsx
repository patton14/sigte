import React from 'react';
import MainCausales from "@/components/maestros/causales-components/main-causales";

const CausalesIndex = () => {
    return (
        <>
            <MainCausales/>
        </>
    );
};

export default CausalesIndex;
