import React from 'react';
import MainUniverso from "@/components/maestros/universo-components/main-universo";

const UniversoIndex = () => {
    return (
        <>
            <MainUniverso/>
        </>
    );
};

export default UniversoIndex;
