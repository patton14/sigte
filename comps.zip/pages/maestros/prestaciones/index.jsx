import React from 'react';
import MainPrestacion from "@/components/maestros/prestacion-components/main-prestacion";

const IndexPrestaciones = () => {
    return (
        <>
            <MainPrestacion/>
        </>
    );
};

export default IndexPrestaciones;
