import React from 'react';
import MainAlertas from "@/components/maestros/alerta-components/main-alertas";

const AlertaIndex = () => {
    return (
        <>
            <MainAlertas/>
        </>
    );
};

export default AlertaIndex;
