import React from 'react';
import MainHomologacionEspecialidad
    from "@/components/maestros/homologacion-especialidad-components/main-homologacion-especialidad";

const HomologacionEspecialidadIndex = () => {
    return (
        <>
            <MainHomologacionEspecialidad/>
        </>
    );
};

export default HomologacionEspecialidadIndex;
