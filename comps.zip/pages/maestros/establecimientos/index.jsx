import React from 'react';
import MainEstablecimiento from "@/components/maestros/establecimientos-components/main-establecimiento";

const IndexEstablecimiento = () => {
    return (
        <>
            <MainEstablecimiento/>
        </>
    );
};

export default IndexEstablecimiento;
